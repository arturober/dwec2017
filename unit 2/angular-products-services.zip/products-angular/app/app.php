<?php
/**
 * Local variables
 * @var \Phalcon\Mvc\Micro $app
 */

/**
 * Add your routes here
 */
$app->get('/', function () {
    echo $this['view']->render('index');
});

/**
 * Not found handler
 */
$app->notFound(function () use($app) {
    $app->response->setStatusCode(404, "Not Found")->sendHeaders();
    echo $app['view']->render('404');
});

$app->get('/products/{id:([0-9]+)}', function($id) {
    $p = Product::findFirstById($id);
    if($p) {
        $prod = $p->toArray();
        $prod['imageUrl'] = 'http://' . $_SERVER['SERVER_NAME'] . $this->url->get('img/' . $prod['imageUrl']); 
        echo json_encode(['ok' => true, 'product' => $prod], JSON_NUMERIC_CHECK);
    } else {
        echo json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']);
    }
});

$app->get('/products', function() {
    $prods = Product::find()->toArray();
    foreach($prods as &$prod) {
        $prod['imageUrl'] = 'http://' . $_SERVER['SERVER_NAME'] . $this->url->get('img/' . $prod['imageUrl']); 
    }
    echo json_encode(['products' => $prods], JSON_NUMERIC_CHECK);
});

$app->post('/products', function() {
    $json = $this->request->getJsonRawBody();
    $prod = new Product();
    $prod->setDescription($json->description);
    $prod->setPrice($json->price);
    $prod->setAvailable($json->available);
    $prod->setRating(0);
    if(substr($json->imageUrl, 0, 4) !== "http") { // Base64
        $nombreFoto = sha1(microtime()) . '.jpg';
        $rutaDir = __DIR__ . '/../public/img/';
        if(!$this->imageUtils->savePhoto($json->imageUrl, $rutaDir, $nombreFoto)) {
            exit(json_encode(['ok' => false, 'error' => 'The image could not be stored...']));
        }
        $prod->setImageUrl($nombreFoto);
    }
    
    if($prod->create()) {
        echo json_encode(['ok' => true, 'id' => $prod->getId()]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error creating the product']);
    }
});

$app->delete('/products/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirstById($id);
    if(!$prod) {
        exit(json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']));
    }
    
    if($prod->delete()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error deleting the product']);
    }
});

$app->put('/products/rating/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirstById($id);
    if(!$prod) {
        exit(json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']));
    }

    $json = $this->request->getJsonRawBody();
    $prod->setRating($json->rating);

    if($prod->update()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error updating the product']);
    }
});

$app->put('/products/{id:([0-9]+)}', function($id) {
    $prod = Product::findFirst('id = ' . $id);
    if(!$prod) {
        exit(json_encode(['ok' => false, 'error' => 'The product doesn\'t exist']));
    }
    
    $json = $this->request->getJsonRawBody();
    $prod->setDescription($json->description);
    $prod->setPrice($json->price);
    $prod->setAvailable($json->available);
    if(substr($json->imageUrl, 0, 4) !== "http") { // Base64
        $nombreFoto = sha1(microtime() . "_" . $id) . '.jpg';
        $rutaDir = __DIR__ . '/../public/img/';
        if(!$this->imageUtils->savePhoto($json->imageUrl, $rutaDir, $nombreFoto)) {
            exit(json_encode(['ok' => false, 'error' => 'The image could not be stored...']));
        }
        $prod->setImageUrl($nombreFoto);
    }
    
    if($prod->update()) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Error updating the product']);
    }
});
