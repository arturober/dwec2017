<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ImageUtils
 *
 * @author arturo
 */
class ImageUtils {
    /**
     * Decodifica una imagen en formato URLEncoded+base64
     * @param string $imgEnc Imagen codificada en URLEncoded+base64
     * @return string con la imagen descodificada (usando imagecreatefromstring se puede convertir a objeto imagen)
     */
    public function decodeImg($imgEnc) {
        $imgEncBody = substr($imgEnc,strpos($imgEnc,",")+1);
        $imgEncBody2 = str_replace(' ','+',$imgEncBody);
        
        return base64_decode($imgEncBody2);
    }
    
    /**
     * Guarda una imagen codificada en base64 al directorio y con el nombre establecido
     * @param type $photoData
     * @param type $dir
     * @param type $name
     * @return boolean
     */
    public function savePhoto($photoData, $dir, $name) {
        $foto = substr($photoData,strpos($photoData,",")+1);
        $encodedFoto = str_replace(' ','+',$foto);
        $decodedFoto = base64_decode($encodedFoto);

        $image = imagecreatefromstring($decodedFoto);
        $rutaImg = $dir . '/' . $name;

        if(imagejpeg($image, $rutaImg)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * A partir de una imagen en formato string, la devuelve en formato cuadrado
     * recortando los laterales (ancho o alto) que correspondan (centrando siempre).
     * @param type $imgStr Imagen en formato string
     * @param type $size Tamaño del cuadrado, se redimensionará si es necesario.
     * @return type 
     */
    public function squareCrop($imgStr, $size) {
        $imgDest = imagecreatetruecolor($size, $size);
        imagecolorallocate($imgDest, 255, 255, 255);
        
        $img    = imagecreatefromstring($imgStr);
        $width  = imagesx($img);
        $height = imagesy($img);
        
        if($width > $height) {
            $src_x = ($width - $height)/2;
            $src_y = 0;
            $src_w = $src_h = $height; 
        } else {
            $src_y = ($height - $width)/2;
            $src_x = 0;
            $src_w = $src_h = $width; 
        }
        
        imagecopyresized($imgDest, $img , 0 , 0 , $src_x , $src_y , $size , $size , $src_w , $src_h);
        
        return $imgDest;
    }
}
